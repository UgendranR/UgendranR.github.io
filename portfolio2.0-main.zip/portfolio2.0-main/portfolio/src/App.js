import "./App.css";
import { Github, Linkedin, Mail } from "lucide-react";

function App() {
  return (
    <div className="app">
      {/* HERO */}
      <section className="hero">
        <div className="hero-bg" />
        <div className="container hero-content">
          <div>
            <h1>Ugendran R</h1>
            <p className="hero-text">
              Full-Stack Engineer with 2.5+ years of experience designing and
              building high-scale, event-driven systems with strong backend focus
              on performance, distributed systems, and secure APIs.
            </p>

            <div className="actions">
              <a
                className="btn primary"
                href="https://drive.google.com/file/d/19ankbCkX59VZCVvoqjRXxZ-DahAeyL2J/view"
              >
                Download Resume
              </a>
              <a className="btn outline" href="#projects">
                View Work
              </a>
            </div>
          </div>

          <img src="/me.jpg" alt="Ugendran R" className="profile" />
        </div>
      </section>

      {/* METRICS */}
      <section className="container metrics">
        {[
          "25GB+ Data Exports",
          "Sub-millisecond APIs",
          "Kafka-Driven Pipelines",
          "Enterprise-grade Security",
        ].map((m) => (
          <div key={m} className="metric">
            {m}
          </div>
        ))}
      </section>

     {/* EXPERIENCE */}
<section className="container">
  <h2>Experience</h2>

  <div className="timeline">
    {/* Zoho Full-Time */}
    <div className="timeline-item">
      <h3>Full-Stack Engineer — Zoho</h3>
      <span>Jun 2023 – Present</span>

      <p className="experience-summary">
        Working on enterprise-scale reporting and export platforms with a strong
        focus on backend architecture, performance optimization, security, and
        frontend integration.
      </p>

      <ul>
        <li>
          Took end-to-end ownership of the Reports & Export Platform, responsible
          for architecture, scalability, reliability, and long-term maintenance.
        </li>

        <li>
          Designed and implemented Kafka-based asynchronous pipelines to handle
          long-running export jobs, enabling fault-tolerant and resumable exports
          for datasets larger than 25GB.
        </li>

        <li>
          Refactored report-generation APIs and optimized database queries by
          adding proper indexing and improving query patterns, reducing response
          times from multiple seconds to sub-millisecond latency for frequently
          used endpoints.
        </li>

        <li>
          Implemented secure API payload encryption using AES along with
          public–private key mechanisms to protect sensitive report data during
          transmission and storage.
        </li>

        <li>
          Designed and enforced fine-grained role-based access control (RBAC) to
          ensure that reports and exports were accessible only to authorized
          administrators and departments.
        </li>

        <li>
          Built real-time export progress tracking using WebSockets, allowing
          users to monitor long-running exports without blocking HTTP requests
          or refreshing the page.
        </li>
      </ul>
    </div>

    {/* Zoho Internship */}
    <div className="timeline-item">
      <h3>Project Trainee — Zoho</h3>
      <span>Aug 2022 – Jun 2023</span>

      <p className="experience-summary">
        Focused on frontend development while gaining exposure to large-scale
        backend systems and enterprise UI requirements.
      </p>

      <ul>
        <li>
          Developed a scalable File Manager UI using React, capable of handling
          large datasets with efficient rendering, filtering, sorting, and
          search functionality.
        </li>

        <li>
          Integrated an internal AI-powered endpoint to generate session
          summaries from remote support actions and chat logs, improving support
          efficiency and context sharing.
        </li>

        <li>
          Improved UI responsiveness and usability by optimizing rendering
          logic, improving component structure, and applying responsive design
          principles.
        </li>

        <li>
          Ensured accessibility compliance by following WCAG guidelines and
          implementing RTL (Right-to-Left) language support where required.
        </li>
      </ul>
    </div>
  </div>
</section>


      {/* PROJECTS */}
      <section id="projects" className="container">
        <h2>Projects & Work</h2>
        <div className="grid">
          <Card title="Reports & Export Platform" />
          <Card title="Distributed Kafka Pipeline" />
          <Card title="API Performance Optimization" />
          <Card title="Security & Access Control" />
          <Card title="Client Support Portal" />
          <Card title="File Manager & AI Summaries" />
        </div>
      </section>

      {/* FOOTER */}
      <footer className="footer container">
        <p>© {new Date().getFullYear()} Ugendran R</p>
        <div className="social">
          <a href="https://github.com/UgendranR"><Github /></a>
          <a href="https://linkedin.com/in/ugendran-r-1383b5193"><Linkedin /></a>
          <a href="mailto:ugendranragu@gmail.com"><Mail /></a>
        </div>
      </footer>
    </div>
  );
}

function Card({ title }) {
  return (
    <div className="card">
      <h3>{title}</h3>
      <p>
        Production-grade system focusing on scalability, reliability, and
        performance.
      </p>
    </div>
  );
}

export default App;
